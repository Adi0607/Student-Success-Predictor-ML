import streamlit as st
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import Perceptron, LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from imblearn.over_sampling import SMOTE
import joblib

# Load data
data = pd.read_csv("AI-Data.csv")
label_encoders = {}

# Preprocess
def preprocess(data):
    drop_cols = ["gender", "StageID", "GradeID", "NationalITy", "PlaceofBirth", 
                 "SectionID", "Topic", "Semester", "Relation", 
                 "ParentschoolSatisfaction", "ParentAnsweringSurvey", 
                 "AnnouncementsView"]
    data = data.drop(columns=drop_cols)
    
    for column in data.columns:
        if data[column].dtype == object:
            le = LabelEncoder()
            data[column] = le.fit_transform(data[column])
            label_encoders[column] = le
    return data

data = preprocess(data)

# Features and labels
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# SMOTE to handle imbalance
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.3, random_state=42)

# Models
models = {
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(),
    "Perceptron": Perceptron(),
    "Logistic Regression": LogisticRegression(),
    "MLP Neural Network": MLPClassifier(activation="logistic")
}

# Sidebar
st.sidebar.title("Choose Classifier")
classifier_name = st.sidebar.selectbox("Classifier", list(models.keys()))

model = models[classifier_name]
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
st.subheader("Model Evaluation")
st.text(classification_report(y_test, y_pred))

# Input Form
st.subheader("Predict Class for a New Student")
rai = st.number_input("Raised Hands", min_value=0)
res = st.number_input("Visited Resources", min_value=0)
dis = st.number_input("Discussions", min_value=0)
absc = st.radio("Absence (Under-7 or Above-7)", ['Under-7', 'Above-7'])

absc_val = 1 if absc == 'Under-7' else 0
user_input = np.array([[rai, res, dis, absc_val]])

if st.button("Predict"):
    pred = model.predict(user_input)
    class_map = {0: "H", 1: "M", 2: "L"}
    st.success(f"Predicted Class: {class_map.get(pred[0], 'Unknown')}")
