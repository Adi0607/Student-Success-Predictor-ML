
# Student Performance Prediction - ML Project

This project predicts the key factors affecting student grades using machine learning models.

## Dataset
The dataset includes students from different nationalities and grade levels with factors like:
- Number of hands raised
- Number of attendance days
- Number of hours studied

## Features
- Data balancing with **SMOTE**
- Multiple classifiers tested (Logistic Regression, Decision Tree, Random Forest, SVM)
- **GridSearchCV** for hyperparameter tuning
- GUI built with **Tkinter** for easy predictions
- Visualizations like confusion matrices and feature importance graphs

## Folder Structure
```
StudentPerformance/
│
├── AI-Data.csv            # Dataset
├── Project.py             # Model training and evaluation
├── app.py                 # GUI application
├── README.md              # Project overview
├── .gitignore             # Git ignored files
├── requirements.txt       # Required libraries
```

## How to Run
1. Install the requirements:
    ```bash
    pip install -r requirements.txt
    ```
2. Run the main application:
    ```bash
    python app.py
    ```

## Requirements
- Python 3.x
- Pandas
- NumPy
- Scikit-learn
- Imbalanced-learn
- Tkinter
- Matplotlib
- Seaborn

---

> Project by Aditya Chugh 🚀
